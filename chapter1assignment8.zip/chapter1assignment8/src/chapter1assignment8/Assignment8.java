package chapter1assignment8;

public class Assignment8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println("     J        A       V       V       A");
System.out.println("     J       A A       V     V       A A");
System.out.println("     J      A   A       V   V       A   A");
System.out.println("J    J     AAAAAAA       V V       AAAAAAA");
System.out.println("JJJJJJ    A       A       V       A       A");
	}

}
