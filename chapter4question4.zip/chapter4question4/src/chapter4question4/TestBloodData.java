package chapter4question4;



public class TestBloodData {



	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 BloodData testSubject1 = new BloodData(BloodData);
		
		
		System.out.println("BloodType: " +  testSubject1.getBloodType());
		System.out.println("Factor: " +  testSubject1.getFactor());
	}

}
