package interest;

public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String user1;
	}
		
		
		
		public static void getData();
		{
			return startBalance *.5;
		}
		
		showValues()
		{
			
		}
			


}
