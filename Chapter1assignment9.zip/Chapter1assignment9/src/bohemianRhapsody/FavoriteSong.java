package bohemianRhapsody;

public class FavoriteSong {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Is this the real life?");
		System.out.println("Or is this just fantasy?");
		System.out.println("Caught in a land slide");
		System.out.println("No escape from reality");
	}

}
